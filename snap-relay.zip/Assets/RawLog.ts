@component
export class RawLog extends BaseScriptComponent {
    @input
    internetModule: InternetModule; // Stripped 'Asset.' prefix

    @input
    displayTarget: Text;           // Stripped 'Component.' prefix

    private socket: any;

    onAwake() {
        // Pointing to your exact Windows wireless interface IP
        const serverUrl = "ws://192.168.4.37:8000/ws/devices";
        
        if (this.displayTarget) this.displayTarget.text = "Awaiting Relay Socket...";
        
        // The global InternetModule instance creates the link
        this.socket = this.internetModule.createWebSocket(serverUrl);

        this.socket.onopen = () => {
            if (this.displayTarget) this.displayTarget.text = "Socket open! Stream ready...";
        };

        this.socket.onmessage = (event: any) => {
            if (this.displayTarget && event.data) {
                this.displayTarget.text = event.data;
            }
        };
        
        this.socket.onerror = (err: any) => {
            if (this.displayTarget) this.displayTarget.text = "Socket Link Error.";
        };
    }
}